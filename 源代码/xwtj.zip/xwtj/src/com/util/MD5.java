package com.util;

/**
 *MD5���������
 *
 */

import java.security.*; 
import java.security.spec.*; 
public final class MD5 {
	
	public final static String MD5(String s){ 
		 
			return s; 
		 
	}
}
