package com.util;
public class SmartUploadException extends Exception
{
    SmartUploadException(String s)
    {
        super(s);
    }
}
